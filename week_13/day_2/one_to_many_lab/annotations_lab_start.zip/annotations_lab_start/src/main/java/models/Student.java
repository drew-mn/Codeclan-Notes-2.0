package models;

public class Student {
}

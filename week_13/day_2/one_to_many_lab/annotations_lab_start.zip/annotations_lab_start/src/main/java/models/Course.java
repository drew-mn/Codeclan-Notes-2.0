package models;

public class Course {
}
